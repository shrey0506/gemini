from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agent import create_agent

chat_router = APIRouter()

class ChatRequest(BaseModel):
    userid: str
    conversationid: str
    question: str
    modelname: str

@chat_router.post("/")
async def chat(request: ChatRequest):
    try:
        agent = create_agent(request.modelname)
        response = agent.run(request.question)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
