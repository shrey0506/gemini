from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import requests
from chunking import process_document
from vectorstore import store_embeddings

upload_router = APIRouter()

class UploadRequest(BaseModel):
    conversationid: str
    userid: str
    gcs_signed_url: str

@upload_router.post("/")
async def upload_file(request: UploadRequest):
    try:
        response = requests.get(request.gcs_signed_url)
        if response.status_code != 200:
            raise HTTPException(status_code=400, detail="File fetch failed.")

        chunks = process_document(response.content)
        store_embeddings(request.conversationid, request.userid, chunks)

        return {"message": "File processed successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
