from PyPDF2 import PdfReader
import textract

def process_document(file_content):
    text = None
    if file_content.startswith(b"%PDF"):
        text = extract_text_from_pdf(file_content)
    else:
        text = textract.process(file_content).decode("utf-8")

    chunks = []
    words = text.split()
    window_size = 100
    overlap = 20

    for i in range(0, len(words), window_size - overlap):
        chunks.append(" ".join(words[i : i + window_size]))

    return chunks

def extract_text_from_pdf(file_content):
    reader = PdfReader(file_content)
    text = "
".join([page.extract_text() for page in reader.pages if page.extract_text()])
    return text
