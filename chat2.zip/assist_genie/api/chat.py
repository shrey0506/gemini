from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from assist_genie.core.embeddings import get_query_embedding
from assist_genie.services.llm_service import generate_summary
from assist_genie.services.alloydb_service import fetch_relevant_chunks

chat_router = APIRouter(prefix="/assist-genie/api/v1/chat", tags=["Chat"])

class ChatRequest(BaseModel):
    userid: str
    conversationid: str
    question: str
    model: dict

@chat_router.post("/")
async def chat(request: ChatRequest):
    query_embedding = get_query_embedding(request.question)
    relevant_chunks = fetch_relevant_chunks(query_embedding)
    response = generate_summary(relevant_chunks, request.model)
    return {"response": response}
