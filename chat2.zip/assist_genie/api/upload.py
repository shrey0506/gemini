from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from assist_genie.services.file_processor import process_file

upload_router = APIRouter(prefix="/assist-genie/api/v1/upload", tags=["Upload"])

class UploadRequest(BaseModel):
    conversationid: str
    userid: str
    gcs_signed_url: str

@upload_router.post("/")
async def upload(request: UploadRequest):
    result = process_file(request.gcs_signed_url, request.conversationid)
    return {"message": "File processed", "details": result}
