from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

def get_query_embedding(query: str):
    return model.encode(query)
