from sqlalchemy import create_engine

DATABASE_URL = "your_alloydb_connection_string"

engine = create_engine(DATABASE_URL)
