from langchain.agents import AgentType, initialize_agent
from langchain.tools import DuckDuckGoSearchTool
from assist_genie.core.embeddings import get_query_embedding
from assist_genie.services.alloydb_service import fetch_relevant_chunks
from assist_genie.services.llm_service import generate_summary

def agentic_response(query: str, model: dict):
    query_embedding = get_query_embedding(query)
    relevant_chunks = fetch_relevant_chunks(query_embedding)

    agent = initialize_agent(
        agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        tools=[DuckDuckGoSearchTool()],
        verbose=True
    )
    
    return generate_summary(relevant_chunks, model)
