from assist_genie.core.database import engine
from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
session = Session()

def fetch_relevant_chunks(query_embedding):
    return ["Relevant chunk 1", "Relevant chunk 2"]
