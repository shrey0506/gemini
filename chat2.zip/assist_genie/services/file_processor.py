import requests
from assist_genie.core.chunking import chunk_text

def process_file(gcs_signed_url: str, conversationid: str):
    response = requests.get(gcs_signed_url)
    
    if response.status_code == 200:
        text_content = response.text
        chunks = chunk_text(text_content)
        return {"chunks": chunks}
    
    raise ValueError("Error downloading file")
