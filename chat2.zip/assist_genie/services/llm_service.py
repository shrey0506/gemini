from assist_genie.core.agent import agentic_response

def generate_summary(chunks, model):
    context = " ".join(chunks)
    return agentic_response(context, model)
