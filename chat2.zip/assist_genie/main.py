from fastapi import FastAPI
from assist_genie.api.chat import chat_router
from assist_genie.api.upload import upload_router

app = FastAPI(title="Agentic AI Solution")

app.include_router(chat_router)
app.include_router(upload_router)

@app.get("/")
def home():
    return {"message": "Agentic AI Solution Running"}
