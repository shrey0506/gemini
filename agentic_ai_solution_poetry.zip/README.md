# Agentic AI Solution

## Setup Instructions

### Using pip:
```sh
pip install -r requirements.txt
```

### Using Poetry:
```sh
poetry install
```

## Running the Application
```sh
uvicorn main:app --reload
```
