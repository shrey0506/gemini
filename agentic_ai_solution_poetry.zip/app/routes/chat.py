from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

chat_router = APIRouter()

class ChatRequest(BaseModel):
    userid: str
    conversationid: str
    question: str
    model: dict  # {"name": "gemini" or "llama", "version": "gemini-1.5-pro-flash" or "llama_90b_mass"}

@chat_router.post("/")
async def chat(request: ChatRequest):
    return {"message": "Chat API called", "model": request.model}
