import mimetypes
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import requests

upload_router = APIRouter()

class UploadRequest(BaseModel):
    conversationid: str
    userid: str
    gcs_signed_url: str

@upload_router.post("/")
async def upload_file(request: UploadRequest):
    return {"message": "Upload API called"}
