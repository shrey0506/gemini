from pydantic import BaseModel

class ChatRequest(BaseModel):
    userid: str
    conversationid: str
    question: str
    model: dict  # {"name": "gemini" or "llama", "version": "gemini-1.5-pro-flash" or "llama_90b_mass"}
