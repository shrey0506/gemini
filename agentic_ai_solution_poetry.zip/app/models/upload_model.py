from pydantic import BaseModel

class UploadRequest(BaseModel):
    conversationid: str
    userid: str
    gcs_signed_url: str
