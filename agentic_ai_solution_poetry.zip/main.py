from fastapi import FastAPI
from app.routes.chat import chat_router
from app.routes.upload import upload_router

app = FastAPI()

app.include_router(chat_router, prefix="/chat", tags=["Chat"])
app.include_router(upload_router, prefix="/upload", tags=["Upload"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
