# db_manager.py - Manages chat history and embeddings in AlloyDB

import psycopg2
from app.config.config_loader import load_config

config = load_config()
DB_PARAMS = config["database"]

def get_db_connection():
    return psycopg2.connect(**DB_PARAMS)

def save_chat(conversation_id, user_id, question, response):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO chat_history (conversation_id, user_id, question, response) VALUES (%s, %s, %s, %s)",
        (conversation_id, user_id, question, response),
    )
    conn.commit()
    cursor.close()
    conn.close()

def get_chat_history(conversation_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT question, response FROM chat_history WHERE conversation_id = %s ORDER BY id ASC", (conversation_id,))
    history = cursor.fetchall()
    cursor.close()
    conn.close()
    return history

def store_document_embedding(conversation_id, user_id, embedding):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO document_embeddings (conversation_id, user_id, embedding) VALUES (%s, %s, %s)",
        (conversation_id, user_id, embedding),
    )
    conn.commit()
    cursor.close()
    conn.close()

def get_similar_data(query_embedding):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT data FROM document_embeddings ORDER BY embedding <-> %s LIMIT 5", (query_embedding,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results
