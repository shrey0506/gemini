# view.py - Handles API endpoints

from fastapi import APIRouter
from app.controllers.controller import process_chat, process_upload
from pydantic import BaseModel

router = APIRouter()

class ChatRequest(BaseModel):
    conversation_id: str
    user_id: str
    question: str
    model: dict

class UploadRequest(BaseModel):
    gcs_signed_url: str
    conversation_id: str
    user_id: str

@router.post("/chat")
def chat_api(request: ChatRequest):
    return process_chat(request.conversation_id, request.user_id, request.question, request.model)

@router.post("/upload")
def upload_api(request: UploadRequest):
    return process_upload(request.gcs_signed_url, request.conversation_id, request.user_id)
