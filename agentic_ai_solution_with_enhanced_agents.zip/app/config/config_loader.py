# config_loader.py - Loads YAML configuration

import yaml

def load_config():
    with open("app/config/config.yaml", "r") as f:
        return yaml.safe_load(f)
