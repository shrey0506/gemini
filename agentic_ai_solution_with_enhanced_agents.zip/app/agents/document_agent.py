# document_agent.py - Handles document embedding storage

from langchain.embeddings import VertexAIEmbeddings
from app.utils.db_manager import store_document_embedding

def process_document_upload(gcs_signed_url, conversation_id, user_id):
    text_content = extract_text_from_gcs(gcs_signed_url)
    embedding_model = VertexAIEmbeddings(model_name="textembedding-gecko@latest")
    document_embedding = embedding_model.embed_documents([text_content])
    store_document_embedding(conversation_id, user_id, document_embedding)
    return {"message": "Document processed successfully", "conversation_id": conversation_id}
