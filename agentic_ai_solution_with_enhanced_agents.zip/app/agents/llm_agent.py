# llm_agent.py - Calls LLM with chat history

from app.llm_models.gemini import GeminiModel
from app.llm_models.llama import LlamaModel
from app.utils.db_manager import save_chat, get_chat_history

def call_llm(conversation_id, user_id, question, model, context):
    chat_history = get_chat_history(conversation_id)
    formatted_history = "\n".join([f"User: {q}\nBot: {r}" for q, r in chat_history])
    prompt = f"{context}\n{formatted_history}\nUser: {question}\nBot:"

    llm = GeminiModel() if model["name"] == "gemini" else LlamaModel()
    response = llm.call_model(prompt)

    save_chat(conversation_id, user_id, question, response)
    return {"conversation_id": conversation_id, "user_id": user_id, "response": response}
