# embedding_agent.py - Converts query to embeddings

from langchain.embeddings import VertexAIEmbeddings
from app.utils.db_manager import get_similar_data

def get_query_embedding(query):
    embedding_model = VertexAIEmbeddings(model_name="textembedding-gecko@latest")
    return embedding_model.embed_query(query)

def retrieve_relevant_data(query_embedding):
    return get_similar_data(query_embedding)
