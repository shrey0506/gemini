# controller.py - Handles business logic

from app.agents.embedding_agent import get_query_embedding, retrieve_relevant_data
from app.agents.llm_agent import call_llm
from app.agents.document_agent import process_document_upload

def process_chat(conversation_id, user_id, question, model):
    embedding = get_query_embedding(question)
    relevant_data = retrieve_relevant_data(embedding)
    return call_llm(conversation_id, user_id, question, model, relevant_data)

def process_upload(gcs_signed_url, conversation_id, user_id):
    return process_document_upload(gcs_signed_url, conversation_id, user_id)
