from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agent import create_agent

chat_router = APIRouter()

class ChatRequest(BaseModel):
    userid: str
    conversationid: str
    question: str
    model: dict  # {"name": "gemini" or "llama", "version": "gemini-1.5-pro-flash" or "llama_90b_mass"}

@chat_router.post("/")
async def chat(request: ChatRequest):
    try:
        agent = create_agent(request.model["name"], request.model["version"])
        response = agent.run(request.question)
        return {"response": response, "model_used": request.model}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
