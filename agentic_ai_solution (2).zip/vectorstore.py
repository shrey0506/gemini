import psycopg2
from sentence_transformers import SentenceTransformer
import numpy as np

DB_CONFIG = {
    "dbname": "alloydb",
    "user": "your_user",
    "password": "your_password",
    "host": "your_host",
    "port": 5432,
}

model = SentenceTransformer("all-MiniLM-L6-v2")

def store_embeddings(conversationid, userid, chunks):
    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor()

    for chunk in chunks:
        embedding = model.encode(chunk).tolist()
        cur.execute(
            "INSERT INTO document_chunks (conversationid, userid, chunk, embedding) VALUES (%s, %s, %s, %s)",
            (conversationid, userid, chunk, embedding),
        )

    conn.commit()
    cur.close()
    conn.close()

def get_relevant_chunks(conversationid, query):
    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor()

    query_embedding = model.encode(query).tolist()
    cur.execute("SELECT chunk, embedding FROM document_chunks WHERE conversationid = %s", (conversationid,))
    
    results = cur.fetchall()
    cur.close()
    conn.close()

    similarities = [(chunk, np.dot(query_embedding, np.array(embedding))) for chunk, embedding in results]
    sorted_chunks = sorted(similarities, key=lambda x: x[1], reverse=True)[:5]
    
    return [chunk for chunk, _ in sorted_chunks]
