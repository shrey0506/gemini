import fitz  # PyMuPDF for PDFs
import docx
import re
from typing import List

def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    """Extracts text from a PDF file."""
    doc = fitz.open("pdf", pdf_bytes)
    text = "
".join([page.get_text("text") for page in doc])
    return text

def extract_text_from_docx(docx_bytes: bytes) -> str:
    """Extracts text from a DOCX file."""
    from io import BytesIO
    doc = docx.Document(BytesIO(docx_bytes))
    text = "
".join([para.text for para in doc.paragraphs])
    return text

def extract_text_from_txt(txt_bytes: bytes) -> str:
    """Extracts text from a TXT file."""
    return txt_bytes.decode("utf-8")

def dynamic_chunking(text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    """Chunks text dynamically using a sliding window with lookahead."""
    sentences = re.split(r'(?<=[.!?])\s+', text)
    chunks = []
    chunk = []

    for sentence in sentences:
        chunk.append(sentence)
        if len(" ".join(chunk)) >= chunk_size:
            chunks.append(" ".join(chunk))
            chunk = chunk[-(overlap // len(sentence)):]  # Retain overlap

    if chunk:
        chunks.append(" ".join(chunk))
    
    return chunks

def process_document(file_bytes: bytes, file_type: str) -> List[str]:
    """Processes a document based on its type and returns text chunks."""
    if file_type == "pdf":
        text = extract_text_from_pdf(file_bytes)
    elif file_type == "docx":
        text = extract_text_from_docx(file_bytes)
    elif file_type == "txt":
        text = extract_text_from_txt(file_bytes)
    else:
        raise ValueError("Unsupported file type")

    return dynamic_chunking(text)
