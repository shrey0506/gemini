import mimetypes
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import requests
from chunking import process_document
from vectorstore import store_embeddings

upload_router = APIRouter()

class UploadRequest(BaseModel):
    conversationid: str
    userid: str
    gcs_signed_url: str

@upload_router.post("/")
async def upload_file(request: UploadRequest):
    try:
        response = requests.get(request.gcs_signed_url)
        if response.status_code != 200:
            raise HTTPException(status_code=400, detail="File fetch failed.")

        file_bytes = response.content
        file_type = mimetypes.guess_type(request.gcs_signed_url)[0]

        if "pdf" in file_type:
            file_type = "pdf"
        elif "word" in file_type or "docx" in file_type:
            file_type = "docx"
        elif "text" in file_type:
            file_type = "txt"
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")

        chunks = process_document(file_bytes, file_type)
        store_embeddings(request.conversationid, request.userid, chunks)

        return {"message": "File processed successfully.", "file_type": file_type}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
