from langchain.agents import initialize_agent, AgentType
from langchain.memory import ConversationBufferMemory
from langchain.tools import Tool
from langchain.llms import VertexAI
from tools import search_web, retrieve_vectors, summarize_text

def create_agent(model_name, model_version):
    if model_name == "gemini":
        llm = VertexAI(model_name=model_version)
    elif model_name == "llama":
        llm = VertexAI(model_name=model_version)  # Update if different LLM is required

    tools = [
        Tool(name="Web Search", func=search_web, description="Search the web for additional information."),
        Tool(name="Retrieve Vectors", func=retrieve_vectors, description="Retrieve relevant document chunks."),
        Tool(name="Summarization", func=summarize_text, description="Summarize retrieved or searched content."),
    ]

    memory = ConversationBufferMemory(memory_key="history", return_messages=True)

    agent = initialize_agent(
        tools=tools,
        llm=llm,
        agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
        memory=memory,
        verbose=True
    )

    return agent
