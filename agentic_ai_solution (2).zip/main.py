from fastapi import FastAPI
from langserve import add_routes
from upload import upload_router
from chat import chat_router

app = FastAPI(title="Agentic AI API")

# Register API routes
app.include_router(upload_router, prefix="/upload")
app.include_router(chat_router, prefix="/chat")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
