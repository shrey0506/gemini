from langchain.utilities import DuckDuckGoSearchAPIWrapper
from retriever import agentic_rag
from langchain.llms import VertexAI

search = DuckDuckGoSearchAPIWrapper()

def search_web(query):
    return search.run(query)

def retrieve_vectors(conversationid, query):
    return agentic_rag(conversationid, query)

def summarize_text(text):
    llm = VertexAI(model_name="gemini-pro")
    return llm.invoke(f"Summarize this text: {text}")
