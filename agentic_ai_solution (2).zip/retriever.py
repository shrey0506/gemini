import numpy as np
from vectorstore import get_relevant_chunks
from tools import search_web

def agentic_rag(conversationid, query):
    retrieved_chunks = get_relevant_chunks(conversationid, query)

    if not retrieved_chunks:
        return search_web(query)

    return " ".join(retrieved_chunks[:3])
